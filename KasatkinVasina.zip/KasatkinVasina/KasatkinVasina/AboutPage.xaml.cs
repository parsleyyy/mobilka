namespace KasatkinVasina;

public partial class AboutPage : ContentPage
{
	public AboutPage()
	{
		InitializeComponent();
	}

	private void LearnMore_Clicked(object sender, EventArgs e)
	{ 
	
	}

	private async void LearnMore_Clicked(object sender, EventArgs e)
	{
		// Navigt to he specifiend URL in the system browser.
		await Launcher.Default.OpenAsunc("https://aka.ms/maui");
	}
}